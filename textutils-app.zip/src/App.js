import { useState } from 'react';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import TextForm from './components/TextForm';
import About from './components/About';
import Alert from './components/Alert';

function App() {
  const [mode, setMode] = useState('light');
  const [alert, setAlert] = useState(null);

  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type
    })
    setTimeout(() => {
      setAlert(null);
    }, 1500);
  }

  const toggleMode = (cls) => {
    if (mode === "light") {
      setMode("dark");
      document.body.style.backgroundColor = '#042743';
      showAlert("Dark mode has been enabled", "success");
    } else {
      setMode("light");
      document.body.style.backgroundColor = 'white';
      showAlert("Light mode has been enabled", "success");
    }
  }
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route element={<Navbar title="TextUtils" abouttext="About" mode={mode} toggleMode={toggleMode} />}>
            <Route path='/' element={<TextForm showAlert={showAlert} heading="Try TextUtils - word Counter, charactor Counter, Remove extra spaces" mode={mode} />} />
            <Route path='/about' element={<About mode={mode} />} />
          </Route>
        </Routes>
      </BrowserRouter>
      <Alert alert={alert} />
    </div>
  );
}

export default App;
